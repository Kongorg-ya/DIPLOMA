<?php

namespace MediaWiki\Settings\Source;

use RuntimeException;

class RefNotFoundException extends RuntimeException {

}
