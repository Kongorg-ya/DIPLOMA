<?php

namespace MediaWiki\Rest\HeaderParser;

class HeaderParserError extends \RuntimeException {
}
